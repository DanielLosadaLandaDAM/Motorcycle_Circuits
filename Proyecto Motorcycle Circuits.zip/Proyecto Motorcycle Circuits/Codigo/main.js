// Inicializa el mapa y establece la vista en una ubicación y nivel de zoom predeterminados
var map = L.map('map').setView([20, 0], 2); // Coordenadas y zoom inicial

// Capa base de mapa desde OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Definir un icono rojo personalizado para los marcadores
const redIcon = L.icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34]
});

// Lista de circuitos con nombre, coordenadas y enlace
var circuitos = [
    { nombre: "Circuito Internacional de Chang", coords: [14.96, 103.08], enlace: "circuito1.html" },
    { nombre: "Autódromo Internacional de Termas de Río Hondo", coords: [-27.50, -64.91], enlace: "circuito2.html" },
    { nombre: "Circuito de las Américas", coords: [30.13, -97.64], enlace: "circuito3.html" },
    { nombre: "Circuito Internacional de Lusail", coords: [25.49, 51.4548], enlace: "circuito4.html" },
    { nombre: "Circuito de Jerez-Ángel Nieto", coords: [36.7094, -6.0369], enlace: "circuito5.html" },
    { nombre: "Circuito de Bugatti", coords: [47.9565, 0.2075], enlace: "circuito6.html" },
    { nombre: "Circuito de Silverstone", coords: [52.0733, -1.0145], enlace: "circuito7.html" },
    { nombre: "MotorLand Aragón", coords: [41.0789, -0.2071], enlace: "circuito8.html" },
    { nombre: "Autódromo Internacional del Mugello", coords: [43.9987, 11.3712], enlace: "circuito9.html" },
    { nombre: "Circuito de Assen", coords: [52.957, 6.526], enlace: "circuito10.html" },
    { nombre: "Sachsenring", coords: [50.7906, 12.6878], enlace: "circuito11.html" },
    { nombre: "Autódromo de Brno", coords: [49.2046, 16.4454], enlace: "circuito12.html" },
    { nombre: "Red Bull Ring", coords: [47.2197, 14.7647], enlace: "circuito13.html" },
    { nombre: "Circuito de Balaton Park", coords: [47.008056, 18.198889], enlace: "circuito14.html" },
    { nombre: "Circuit de Barcelona-Cataluña", coords: [41.57, 2.2619], enlace: "circuito15.html" },
    { nombre: "Misano World Circuit Marco Simoncelli", coords: [43.961111, 12.683333], enlace: "circuito16.html" },
    { nombre: "Mobility Resort Motegi", coords: [36.5333, 140.225], enlace: "circuito17.html" },
    { nombre: "Circuito Urbano Internacional de Mandalika", coords: [-8.895423, 116.304182], enlace: "circuito18.html" },
    { nombre: "Circuito de Phillip Island", coords: [-38.505, 145.23], enlace: "circuito19.html" },
    { nombre: "Circuito Internacional de Sepang", coords: [2.7608, 101.7382], enlace: "circuito20.html" },
    { nombre: "Autódromo Internacional del Algarve", coords: [37.227, -8.6289], enlace: "circuito21.html" },
    { nombre: "Circuit Ricardo Tormo", coords: [39.4884, -0.6316], enlace: "circuito22.html" },
];

// Añadir marcadores con icono rojo para cada circuito
circuitos.forEach(function(circuito) {
    var marker = L.marker(circuito.coords, { icon: redIcon }).addTo(map);
    marker.bindPopup(`
        <b>${circuito.nombre}</b><br>
        <a href="Codigo/${circuito.enlace}" target="_blank" class="map-link">Ver más</a>
    `);
});


// Función para alternar entre las pestañas
function showTab(tabName) {
    // Oculta todas las pestañas
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.style.display = 'none';
    });
    document.getElementById(tabName).style.display = 'block';

    // Actualiza la clase "active" del botón seleccionado
    document.querySelectorAll('.tab-button').forEach(button => {
        button.classList.remove('active');
    });
    event.currentTarget.classList.add('active');

    // Si la pestaña seleccionada es "ganadores", muestra los ganadores históricos
    if (tabName === 'ganadores') {
        const circuitoNombre = document.querySelector('h1').innerText.replace("Gran Premio de ", "");
        mostrarGanadores(circuitoNombre);
    }
}

// Función para mostrar los ganadores históricos del circuito actual
function mostrarGanadores(circuito) {
    const listaGanadores = ganadoresHistoricos[circuito] || [];
    const listaElement = document.getElementById('ganadores-lista');
    listaElement.innerHTML = ''; // Limpia la lista previa

    // Si no hay ganadores, muestra un mensaje alternativo
    if (listaGanadores.length === 0) {
        const listItem = document.createElement('li');
        listItem.textContent = "No ha habido carreras en este circuito aún.";
        listaElement.appendChild(listItem);
    } else {
        // Si hay ganadores, muestra la lista
        listaGanadores.forEach(entry => {
            const listItem = document.createElement('li');
            listItem.textContent = `${entry.año}: ${entry.ganador}`;
            listaElement.appendChild(listItem);
        });
    }
}
